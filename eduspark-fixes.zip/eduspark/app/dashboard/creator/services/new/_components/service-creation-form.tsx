/* eslint-disable react-hooks/incompatible-library */
"use client";

import {
  useState,
  useEffect,
  useRef,
  useTransition,
  KeyboardEvent,
} from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Combobox } from "@/components/ui/combobox";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { z } from "zod";
import {
  X,
  Plus,
  Loader2,
  Link2,
  Tag,
  DollarSign,
  Clock,
  RotateCcw,
  BookOpen,
  AlertCircle,
  CheckCircle2,
  Trash2,
  Sparkles,
} from "lucide-react";
import { createServiceAction } from "@/actions/marketplace/create-service";
import { updateServiceAction } from "@/actions/marketplace/update-service";
import {
  CreateServiceSchema,
  type CreateServiceInput,
} from "@/actions/marketplace/create-service-schema";
import type { CertifiedCourseOption } from "../page";
import { cn } from "@/lib/utils";

interface ServiceCreationFormProps {
  certifiedCourses: CertifiedCourseOption[];
  mode?: "create" | "edit";
  serviceId?: string;
  initialData?: Partial<CreateServiceInput>;
}

function FormSection({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-800 bg-slate-900/80">
        <h2 className="text-sm font-bold text-slate-200">{title}</h2>
        {description && (
          <p className="text-xs text-slate-500 mt-0.5">{description}</p>
        )}
      </div>
      <div className="p-6 space-y-5">{children}</div>
    </div>
  );
}

function TagInput({
  value,
  onChange,
  error,
  max = 5,
}: {
  value: string[];
  onChange: (tags: string[]) => void;
  error?: string;
  max?: number;
}) {
  const [input, setInput] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const addTag = (raw: string) => {
    const tag = raw.trim().toLowerCase().replace(/[^a-z0-9-]/g, "");
    if (!tag || tag.length < 2 || value.includes(tag) || value.length >= max) {
      setInput("");
      return;
    }
    onChange([...value, tag]);
    setInput("");
  };

  const removeTag = (tag: string) => onChange(value.filter((t) => t !== tag));

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      addTag(input);
    }
    if (e.key === "Backspace" && !input && value.length > 0) {
      onChange(value.slice(0, -1));
    }
  };

  return (
    <div className="space-y-2">
      <div
        onClick={() => inputRef.current?.focus()}
        className={cn(
          "min-h-11 flex flex-wrap gap-1.5 items-center px-3 py-2 rounded-lg",
          "bg-slate-950 border border-slate-700 cursor-text",
          "focus-within:border-indigo-500 focus-within:ring-1 focus-within:ring-indigo-500 transition-all"
        )}
      >
        {value.map((tag) => (
          <Badge
            key={tag}
            variant="secondary"
            className="flex items-center gap-1 bg-indigo-500/10 text-indigo-300 border-indigo-500/20 hover:bg-indigo-500/20 text-xs"
          >
            <Tag className="w-2.5 h-2.5" />
            {tag}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                removeTag(tag);
              }}
              className="ml-0.5 hover:text-indigo-100"
            >
              <X className="w-3 h-3" />
            </button>
          </Badge>
        ))}

        {value.length < max && (
          <input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            onBlur={() => input && addTag(input)}
            placeholder={value.length === 0 ? "Type a tag, press Enter…" : ""}
            className="flex-1 min-w-30 bg-transparent text-sm text-slate-200 placeholder:text-slate-600 outline-none"
          />
        )}
      </div>
      <p className="text-[11px] text-slate-600">
        {value.length}/{max} tags added · Press{" "}
        <kbd className="px-1 py-0.5 rounded bg-slate-800 text-slate-500 font-mono text-[10px]">
          Enter
        </kbd>{" "}
        or{" "}
        <kbd className="px-1 py-0.5 rounded bg-slate-800 text-slate-500 font-mono text-[10px]">
          ,
        </kbd>{" "}
        to add
      </p>
      {error && <p className="text-xs text-red-400">{error}</p>}
    </div>
  );
}

function PortfolioLinksInput({
  value,
  onChange,
}: {
  value: string[];
  onChange: (links: string[]) => void;
}) {
  const addLink = () => {
    if (value.length < 5) onChange([...value, ""]);
  };

  const updateLink = (index: number, url: string) => {
    const updated = [...value];
    updated[index] = url;
    onChange(updated);
  };

  const removeLink = (index: number) =>
    onChange(value.filter((_, i) => i !== index));

  return (
    <div className="space-y-2.5">
      {value.map((link, i) => (
        <div key={i} className="flex items-center gap-2">
          <div className="relative flex-1">
            <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-600" />
            <input
              type="url"
              value={link}
              onChange={(e) => updateLink(i, e.target.value)}
              placeholder="https://your-portfolio.com/project"
              className={cn(
                "w-full pl-9 pr-4 py-2.5 rounded-lg text-sm",
                "bg-slate-950 border border-slate-700 text-slate-200",
                "placeholder:text-slate-600",
                "focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500",
                "transition-all"
              )}
            />
          </div>
          <button
            type="button"
            onClick={() => removeLink(i)}
            className="flex items-center justify-center w-9 h-9 rounded-lg hover:bg-red-500/10 text-slate-600 hover:text-red-400 transition-colors border border-slate-700 hover:border-red-500/30"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}

      {value.length < 5 && (
        <button
          type="button"
          onClick={addLink}
          className="flex items-center gap-2 text-xs text-indigo-400 hover:text-indigo-300 font-medium transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          Add portfolio link {value.length > 0 ? `(${value.length}/5)` : ""}
        </button>
      )}
    </div>
  );
}

function NumberInput({
  value,
  onChange,
  min,
  max,
  prefix,
  suffix,
  step = 1,
  placeholder,
}: {
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
  prefix?: string;
  suffix?: string;
  step?: number;
  placeholder?: string;
}) {
  const [text, setText] = useState<string>(() =>
    value === 0 ? "" : String(value)
  );
  const lastEmittedRef = useRef(value);

  useEffect(() => {
    if (value !== lastEmittedRef.current) {
      setText(value === 0 ? "" : String(value));
      lastEmittedRef.current = value;
    }
  }, [value]);

  const isDecimal = step < 1;
  const allowedRegex = isDecimal ? /^\d*\.?\d*$/ : /^\d*$/;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    if (raw !== "" && !allowedRegex.test(raw)) return;

    setText(raw);

    if (raw === "" || raw === ".") return;

    const parsed = isDecimal ? parseFloat(raw) : parseInt(raw, 10);
    if (!isNaN(parsed)) {
      lastEmittedRef.current = parsed;
      onChange(parsed);
    }
  };

  const handleBlur = () => {
    if (text === "" || text === ".") {
      const fallback = min ?? 0;
      setText(fallback === 0 ? "" : String(fallback));
      lastEmittedRef.current = fallback;
      onChange(fallback);
      return;
    }

    let parsed = isDecimal ? parseFloat(text) : parseInt(text, 10);
    if (isNaN(parsed)) parsed = min ?? 0;
    if (min !== undefined && parsed < min) parsed = min;
    if (max !== undefined && parsed > max) parsed = max;

    setText(String(parsed));
    lastEmittedRef.current = parsed;
    onChange(parsed);
  };

  return (
    <div className="relative flex items-center">
      {prefix && (
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm select-none pointer-events-none">
          {prefix}
        </span>
      )}
      <input
        type="text"
        inputMode={isDecimal ? "decimal" : "numeric"}
        value={text}
        placeholder={placeholder}
        onChange={handleChange}
        onBlur={handleBlur}
        className={cn(
          "w-full py-2.5 rounded-lg text-sm",
          "bg-slate-950 border border-slate-700 text-slate-200",
          "placeholder:text-slate-600",
          "focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500",
          "transition-all",
          prefix ? "pl-7" : "pl-3",
          suffix ? "pr-12" : "pr-3"
        )}
      />
      {suffix && (
        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 text-xs select-none pointer-events-none">
          {suffix}
        </span>
      )}
    </div>
  );
}

function getErrorMessage(code: string | undefined): string {
  switch (code) {
    case "NO_CERTIFICATE":
      return "Your certificate for this course could not be verified. Please ensure you passed the course quiz.";
    case "FORBIDDEN_ROLE":
      return "Your account is not authorized to create services.";
    case "FORBIDDEN":
      return "You don't have permission to edit this service.";
    case "NOT_FOUND":
      return "This service no longer exists.";
    case "MALICIOUS_URL_BLOCKED":
      return "One or more portfolio links were flagged as malicious. Please remove them before saving.";
    case "RATE_LIMITED":
      return "Too many changes in a short time. Please wait a few minutes and try again.";
    case "SERVER_ERROR":
      return "Something went wrong on our end. Please try again.";
    default:
      return "An unexpected error occurred.";
  }
}

export function ServiceCreationForm({
  certifiedCourses,
  mode = "create",
  serviceId,
  initialData,
}: ServiceCreationFormProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [serverError, setServerError] = useState<string | null>(null);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const isEdit = mode === "edit";

  const form = useForm<
    z.input<typeof CreateServiceSchema>,
    unknown,
    CreateServiceInput
  >({
    resolver: zodResolver(CreateServiceSchema),
    defaultValues: {
      courseId: initialData?.courseId ?? "",
      categoryId: initialData?.categoryId ?? null,
      title: initialData?.title ?? "",
      description: initialData?.description ?? "",
      price: initialData?.price ?? 25,
      deliveryDays: initialData?.deliveryDays ?? 3,
      revisions: initialData?.revisions ?? 1,
      tags: initialData?.tags ?? [],
      portfolioLinks: initialData?.portfolioLinks ?? [],
    },
    mode: "onBlur",
  });

  const tags = form.watch("tags") ?? [];
  const portfolioLinks = form.watch("portfolioLinks") ?? [];
  const selectedCourseId = form.watch("courseId");

  const selectedCourse = certifiedCourses.find(
    (c) => c.courseId === selectedCourseId
  );

  const onSubmit = form.handleSubmit((data) => {
    setServerError(null);

    const toastId = toast.loading(
      isEdit ? "Saving changes…" : "Publishing service…"
    );

    startTransition(async () => {
      const result =
        isEdit && serviceId
          ? await updateServiceAction({ ...data, serviceId })
          : await createServiceAction(data);

      if (result.success) {
        setSubmitSuccess(true);
        toast.success(
          isEdit ? "Service updated successfully! ✨" : "Service published! 🚀",
          {
            id: toastId,
            description: "Redirecting to your services…",
          }
        );
        setTimeout(() => router.push("/dashboard/creator/services"), 1200);
        return;
      }

      if (result.fieldErrors) {
        for (const [field, errors] of Object.entries(result.fieldErrors)) {
          form.setError(field as keyof CreateServiceInput, {
            type: "server",
            message: errors?.[0],
          });
        }
      }

      const errorMessage = getErrorMessage(result.error);
      setServerError(errorMessage);
      toast.error(
        isEdit ? "Failed to update service" : "Failed to publish service",
        {
          id: toastId,
          description: errorMessage,
        }
      );
    });
  });

  if (submitSuccess) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <div className="w-20 h-20 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mb-5">
          <CheckCircle2 className="w-10 h-10 text-emerald-400" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">
          {isEdit ? "Service Updated!" : "Service Created!"}
        </h2>
        <p className="text-slate-400 text-sm">
          Redirecting to your services…
        </p>
      </div>
    );
  }

  return (
    <Form {...form}>
      <form onSubmit={onSubmit} className="space-y-6 mt-6">
        <FormSection
          title="Service Foundation"
          description="Link your service to a course you've certified in."
        >
          <FormField
            control={form.control}
            name="courseId"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-slate-300">
                  Certified Course <span className="text-red-400">*</span>
                </FormLabel>
                <FormControl>
                  <Combobox
                    options={certifiedCourses.map((cert) => ({
                      value: cert.courseId,
                      label: cert.courseTitle,
                      description: `Score ${cert.score}% · ${cert.courseLevel}`,
                      icon: (
                        <BookOpen className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                      ),
                    }))}
                    value={field.value}
                    onChange={(v) => field.onChange(v)}
                    placeholder="Select a certified course…"
                    searchPlaceholder="Search courses…"
                    emptyMessage="No matching courses."
                  />
                </FormControl>
                <FormDescription className="text-slate-600 text-xs">
                  Only courses with a passing certificate are listed.
                </FormDescription>
                <FormMessage className="text-red-400 text-xs" />
              </FormItem>
            )}
          />

          {selectedCourse && (
            <div className="flex items-start gap-3 p-3.5 rounded-xl bg-amber-500/5 border border-amber-500/15">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-4 h-4 text-amber-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-amber-300 truncate">
                  {selectedCourse.courseTitle}
                </p>
                <p className="text-[10px] text-slate-500 mt-0.5">
                  Credential{" "}
                  <span className="font-mono text-slate-400">
                    {selectedCourse.credentialId}
                  </span>{" "}
                  · Score{" "}
                  <span className="text-amber-400 font-semibold">
                    {selectedCourse.score}%
                  </span>
                </p>
              </div>
            </div>
          )}

          {/* Category auto-derived notice */}
          <div className="flex items-start gap-2.5 p-3 rounded-lg bg-indigo-500/5 border border-indigo-500/15">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
            <p className="text-[11px] text-indigo-300 leading-relaxed">
              <span className="font-bold">Category is set automatically</span>{" "}
              from your certificate. You can only offer services in categories
              you&apos;re certified in.
            </p>
          </div>
        </FormSection>

        <FormSection
          title="Service Details"
          description="Write a compelling title and description to attract buyers."
        >
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-slate-300">
                  Service Title <span className="text-red-400">*</span>
                </FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    placeholder="e.g. I will build a full-stack Next.js web application…"
                    className="bg-slate-950 border-slate-700 text-slate-200 placeholder:text-slate-600 focus:border-indigo-500 focus:ring-indigo-500 h-10"
                  />
                </FormControl>
                <div className="flex justify-between items-center">
                  <FormMessage className="text-red-400 text-xs" />
                  <span className="text-[10px] text-slate-600 ml-auto">
                    {field.value?.length ?? 0}/100
                  </span>
                </div>
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-slate-300">
                  Description <span className="text-red-400">*</span>
                </FormLabel>
                <FormControl>
                  <Textarea
                    {...field}
                    rows={6}
                    placeholder="Describe exactly what you'll deliver, what's included, your process, and any requirements from the buyer…"
                    className="bg-slate-950 border-slate-700 text-slate-200 placeholder:text-slate-600 focus:border-indigo-500 focus:ring-indigo-500 resize-none"
                  />
                </FormControl>
                <div className="flex justify-between items-center">
                  <FormMessage className="text-red-400 text-xs" />
                  <span className="text-[10px] text-slate-600 ml-auto">
                    {field.value?.length ?? 0}/3000
                  </span>
                </div>
              </FormItem>
            )}
          />
        </FormSection>

        <FormSection
          title="Pricing & Delivery"
          description="Set competitive rates based on your expertise level."
        >
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
            <FormField
              control={form.control}
              name="price"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">
                    <span className="flex items-center gap-1.5">
                      <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                      Price (USD) <span className="text-red-400">*</span>
                    </span>
                  </FormLabel>
                  <FormControl>
                    <NumberInput
                      value={field.value}
                      onChange={field.onChange}
                      min={5}
                      max={10000}
                      step={0.01}
                      prefix="$"
                      placeholder="25.00"
                    />
                  </FormControl>
                  <FormDescription className="text-slate-600 text-xs">
                    Min $5 · Max $10,000
                  </FormDescription>
                  <FormMessage className="text-red-400 text-xs" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="deliveryDays"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-indigo-400" />
                      Delivery Time <span className="text-red-400">*</span>
                    </span>
                  </FormLabel>
                  <FormControl>
                    <NumberInput
                      value={field.value}
                      onChange={field.onChange}
                      min={1}
                      max={90}
                      suffix="days"
                      placeholder="3"
                    />
                  </FormControl>
                  <FormDescription className="text-slate-600 text-xs">
                    1–90 calendar days
                  </FormDescription>
                  <FormMessage className="text-red-400 text-xs" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="revisions"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">
                    <span className="flex items-center gap-1.5">
                      <RotateCcw className="w-3.5 h-3.5 text-violet-400" />
                      Revisions
                    </span>
                  </FormLabel>
                  <FormControl>
                    <NumberInput
                      value={field.value ?? 1}
                      onChange={field.onChange}
                      min={0}
                      max={20}
                      placeholder="1"
                    />
                  </FormControl>
                  <FormDescription className="text-slate-600 text-xs">
                    0 = no revisions
                  </FormDescription>
                  <FormMessage className="text-red-400 text-xs" />
                </FormItem>
              )}
            />
          </div>
        </FormSection>

        <FormSection
          title="Tags & Portfolio"
          description="Help buyers discover your service and see past work."
        >
          <FormField
            control={form.control}
            name="tags"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-slate-300">
                  Tags <span className="text-red-400">*</span>
                </FormLabel>
                <FormControl>
                  <TagInput
                    value={tags}
                    onChange={(newTags) => {
                      field.onChange(newTags);
                      form.setValue("tags", newTags, { shouldValidate: true });
                    }}
                    error={form.formState.errors.tags?.message}
                  />
                </FormControl>
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="portfolioLinks"
            render={() => (
              <FormItem>
                <FormLabel className="text-slate-300">
                  Portfolio Links{" "}
                  <span className="text-slate-600 font-normal text-xs">
                    (optional)
                  </span>
                </FormLabel>
                <FormControl>
                  <PortfolioLinksInput
                    value={portfolioLinks}
                    onChange={(links) =>
                      form.setValue("portfolioLinks", links, {
                        shouldValidate: true,
                      })
                    }
                  />
                </FormControl>
                <FormDescription className="text-slate-600 text-xs">
                  Add up to 5 links to showcase your previous work.
                </FormDescription>
                <FormMessage className="text-red-400 text-xs" />
              </FormItem>
            )}
          />
        </FormSection>

        {serverError && (
          <div className="flex items-start gap-3 p-4 rounded-xl bg-red-500/5 border border-red-500/20">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <p className="text-red-300 text-sm">{serverError}</p>
          </div>
        )}

        <div className="flex items-center justify-end gap-3 pt-2">
          <Button
            type="button"
            variant="ghost"
            onClick={() => router.push("/dashboard/creator/services")}
            disabled={isPending}
            className="text-slate-400 hover:text-slate-200 hover:bg-slate-800"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={isPending}
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold px-8 shadow-lg shadow-indigo-500/20 disabled:opacity-50"
          >
            {isPending ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
                {isEdit ? "Saving…" : "Publishing…"}
              </>
            ) : isEdit ? (
              "Save Changes"
            ) : (
              "Publish Service"
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
}